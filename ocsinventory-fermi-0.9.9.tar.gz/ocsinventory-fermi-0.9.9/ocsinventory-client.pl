#!/usr/bin/perl

  BEGIN {
  if ((-e "/etc/redhat-release") || (-e "/etc/fedora-release"))
  {
    #This is to make sure we only use the perl modules from the version of perl 
    #that is from the vendor,  in particular the one from the rpm and not ups
    #but we only need to do it for redhat type systems
    ($ver,$patch) = split('\.',$]);
    $newversion = $ver . "." . (substr($patch,0,3) + 0) . "." .  (substr($patch,3,3) + 0);
    chomp($proctype =`/bin/uname -i`);
    if ($proctype eq "x86_64") {
       @INC=("/usr/lib64/perl5/$newversion/x86_64-linux-thread-multi", "/usr/lib/perl5/$newversion", "/usr/lib64/perl5/site_perl/$newversion/x86_64-linux-thread-multi", "/usr/lib/perl5/site_perl/$newversion", "/usr/lib64/perl5/vendor_perl/$newversion/x86_64-linux-thread-multi", "/usr/lib/perl5/vendor_perl/$newversion")
  } else    {
       @INC=("/usr/lib/perl5/$newversion/$proctype-linux-thread-multi", "/usr/lib/perl5/$newversion", "/usr/lib/perl5/site_perl/$newversion/$proctype-linux-thread-multi", "/usr/lib/perl5/site_perl/$newversion", "/usr/lib/perl5/vendor_perl/$newversion/$proctype-linux-thread-multi", "/usr/lib/perl5/vendor_perl/$newversion")
            }
  }
    	}

###############################################################################
##OCSInventory Version NG RC2
##Copyleft Pascal DANEK 2005
##Web : http://ocsinventory.sourceforge.net
##
##This code is open source and may be copied and modified as long as the source
##code is always made freely available.
##Please refer to the General Public Licence http://www.gnu.org/ or Licence.txt
################################################################################

use strict;

use XML::Simple;
use LWP::UserAgent;
use Compress::Zlib;
#use Net::IP qw(:PROC);   CJS
use Digest::MD5 qw(md5_base64);

#Data in MB
use constant UNITE => 1024;

#
use constant VERSION =>23;
#
my $log_path		= "/var/log/ocsinventory-client/ocsinv.log";
my $default_server	= "fortytwo.fnal.gov";
my $install_path	= "/etc/ocsinventory-client";
my $exe_path		= "/usr/sbin";
my $debug;
my @bin_directories 	= qw {	 /sbin/ /usr/sbin/ /bin/ /usr/bin/ 
				/usr/local/bin/ /usr/local/sbin/ /etc/ocsinventory-client/};
				
my $checksum = 0;
#To apply to $checksum with an OR
my %mask = (
	'hardware' 	=> 1,
	'bios'		=> 2,
	'memories'	=> 4,
	'slots'		=> 8,
	'registry'	=> 16,
	'controllers'	=> 32,
	'monitors'	=> 64,
	'ports'		=> 128,
	'storages'	=> 256,
	'drives'	=> 512,
	'inputs'	=> 1024,
	'modems'	=> 2048,
	'networks'	=> 4096,
	'printers'	=> 8192,
	'sounds'	=> 16384,
	'videos'	=> 32768,
	'softwares'	=> 65536,
	'listenports'	=> 131072,
	'iptables'	=> 262144
);

######
#MAIN#
############################################################
my(	$req, $res, $ua, $Dversion, $AuthUpdate, $inventory, %request, @lspci,
	%account, @config, $ServerName, $DeviceID, $old_deviceid, $YEAR, $MONTH, $DAY, $HOUR, $MIN, $SEC,
	$xfree, @xconfig, $compress, $xml, $start, $end, $UnitID, $OrderID, $OrderYear, $local,
	$OrderOwner,$ProductID, %xmladm, %xmlconf, $URI, %options, $distro, $Iversion);

my( $XmlLocalDir );

#timestamp at the beginning (to estimate the etime)
$start = time();

# Is there a user to watch to logs ? If not, we put it into the logs file
unless(defined($ENV{USER})){
  open STDOUT, ">>".$log_path;
}else{
  #We notify that an inventory had been manually generated
  open FILE, ">>".$log_path;
  print FILE localtime()." => Generated manually\n";
  close FILE;
}

# Error logs to STDOUT
open STDERR, ">>&STDOUT";

# Checking Permissions
unless(-r "/dev/mem"){
	die localtime()." => You don't have enough rights to run this program\n";
}

#Get last inventory state
#CJS add softwareports and iptables
my $last_state = XML::Simple::XMLin($install_path."/last_state", SuppressEmpty => undef, ForceArray => ['hardware', 'inputs', 'controllers', 'memories', 'monitors', 'ports', 'softwares', 'storages', 'drives', 'inputs', 'modems', 'networks', 'printers', 'slots', 'sounds', 'videos', 'bios', 'listenports', 'iptables' ] ) if -r "$install_path/last_state";
#If data are not available
my %last_state;

# Configuration reading
my $xmlconf = XML::Simple::XMLin($install_path."/ocsinv.conf", SuppressEmpty => undef);
#
$ServerName = $xmlconf->{OCSFSERVER};
$DeviceID   = $xmlconf->{DEVICEID};
$Dversion   = $xmlconf->{DMIVERSION}?$xmlconf->{DMIVERSION}:1;
$Iversion   = $xmlconf->{IPDISCOVER_VERSION}?$xmlconf->{IPDISCOVER_VERSION}:1;
$AuthUpdate = 1 if $xmlconf->{UPDATE} eq '1';
$XmlLocalDir   = $xmlconf->{XMLLOCALDIR};

# Reading Account infos 
my $xmladm = XML::Simple::XMLin( $install_path."/ocsinv.adm", ForceArray => [ 'ACCOUNTINFO' ] );
for(@{$xmladm->{ACCOUNTINFO}}){
	$account{$_->{KEYNAME}} = $_->{KEYVALUE};
}

# Reading parameters
$local=0;
for(@ARGV){
	if(/-local/) {
		$ServerName = 'local';
		$local=1;
	}elsif(/-server=(\S+)/) {
		$ServerName = $1 }
	elsif(/-update/){
		&_update('test');
		exit(0);
	}elsif(/-xml/){
		$xml=1
	}elsif(/-debug/){
		$debug = 2;
	}elsif(/-info/){
		$debug = 1;
	}else{
		die print localtime()." => Unknown argument = $_\nArret...\n";
	}

}

print <<EOF if $debug;

####################
#OCSINVENTORY NG
#Linux agent report
####################


EOF


#Setting binaries locations
my $dmidecode_path 	= &_get_path('dmidecode');
my $ifconfig_path 	= &_get_path('ifconfig');
my $ipdiscover_path 	= &_get_path('ipdiscover');
my $route_path		= &_get_path('route');
my $df_path		= &_get_path('df');
my $lspci_path		= &_get_path('lspci');
my $who_path		= &_get_path('who');
my $uname_path		= &_get_path('uname');
#CJS might as well add iptables and netstat
my $netstat_path	= &_get_path('netstat');
my $iptables_path	= &_get_path('iptables');
my $grep_path		= &_get_path('grep');

#Get the binaries output
#ifconfig
my @ifconfig = `env LANGUAGE=us $ifconfig_path`;
#dmidecode
my @dmidecode = `env LANGUAGE=us $dmidecode_path`;
# Remove spaces at the beginning of lines
s/^\s+// for (@dmidecode);

# Checking DeviceID
chomp(my $Device = `$uname_path -n| cut -d . -f 1`);
unless($DeviceID=~/$Device-(?:\d{4})(?:-\d{2}){5}/){
	# We save the old deviceid in order to tell to the server that we changed
	$old_deviceid = $DeviceID;

	# Building DeviceID
	($YEAR, $MONTH , $DAY, $HOUR, $MIN, $SEC) = (localtime (time))[5,4,3,2,1,0];
	$DeviceID=sprintf "%s-%02d-%02d-%02d-%02d-%02d-%02d",  $Device, ($YEAR+1900), ($MONTH+1), $DAY, $HOUR, $MIN, $SEC;

	# writing ocsinv.conf
	$xmlconf{'DEVICEID'}		= [ $DeviceID ];
	if($ServerName eq 'local'){
		$xmlconf{'OCSFSERVER'}		= [ $default_server ];
	} else {
		$xmlconf{'OCSFSERVER'}		= [ $ServerName ];
	}
	$xmlconf{'DMIVERSION'}		= [ $Dversion ];
	$xmlconf{'IPDISCOVER_VERSION'}	= [ $Iversion ];
	$xmlconf{'XMLLOCALDIR'}		= [ '/etc/ocsinventory-client' ];
	$xmlconf{'UPDATE'}		= [ "1" ] if $AuthUpdate;
	
	my $xml = XML::Simple::XMLout( \%xmlconf, RootName => 'CONF' );
	
	open CONF, ">".$install_path."/ocsinv.conf";
	print CONF $xml;
	close CONF;
}

# Server default name
$ServerName = $default_server unless($ServerName);

# URI
$URI = "http://".$ServerName."/ocsinventory";

# Proceed...
if(($ServerName=~/^local$/i) or $xml){
	&_inventory();
}else{
	# Connect to server
	$ua = LWP::UserAgent->new(keep_alive => 1);
	$ua->agent('OCS-NG_linux_client_v'.VERSION);

	# Update if needed
	if($AuthUpdate){
		&_update();
	}

	# Contact the server
	if(&_prolog()){
		# Send inventory if needed
		&_inventory();
	}
}

# That's all
print localtime()." => Finished... \n";
print localtime()." => Execution time : ".(($end?$end:time()) - $start)." secs\n";

############
#SUBROUTINES
############
#
sub _hardware{
	my (	$OSVersion, $OSName, $OSComment, $DeviceType, $PhysicalMemory,
		$SwapFileSize, $ip, @ip, $UsersLoggedOn, @users, $domain, $uptime,
		$UYEAR, $UMONTH , $UDAY, $UHOUR, $UMIN, $USEC, %processors, $distro_file , @scratch, @scratch2);

	# Operating system informations
	chomp($OSName =`$uname_path -s`);
	chomp($OSVersion =`$uname_path -r`);
	chomp($OSComment =`$uname_path -v`);
	chomp($DeviceType =`$uname_path -m`);

	# Wich distro ?
	if(-e "/etc/mandrake-release"){
		$distro = 'Mandrake';
		$distro_file = "/etc/mandrake-release";
	}elsif(-e "/etc/fedora-release"){
	   	$distro = 'Fedora';
		$distro_file = "/etc/fedora-release";
#We need to put in Fermi STS if it is really Fermi STS
	        open DISTRO, $distro_file;
	        while(<DISTRO>){
		      $distro="Fermi STS" if /STS/i;
                }
	}elsif(-e "/etc/redhat-release"){
		$distro = 'Redhat';
		$distro_file = "/etc/redhat-release";
#We need to put in Scientific Linux if it is really Scientific Linux
	        open DISTRO, $distro_file;
	        while(<DISTRO>){
		      $distro="Scientific Linux" if /^Scientific/i;
                }
	}elsif(-e "/etc/lsb-release"){
#We need to figure out what distro this is 
		$distro_file = "/etc/lsb-release";
	        open DISTRO, $distro_file;
	        while(<DISTRO>){
		      @scratch[1] = "NONE" ;
		      @scratch2[1] = "NONE" ;
#		      print $_  . "\n";
    		      @scratch = split(/"/,$_) if /DISTRIB_DESCRIPTION/i; 
# 		      print "scratch1: " . @scratch[1] . "\n" ;
		      if ( @scratch[1] ne "NONE" ) {
		          $OSComment = @scratch[1] ;
#			  print "OSComment is : " . $OSComment . "\n" ;
		          $distro_file="" ;
		      }
    		      @scratch2 = split(/=/,$_) if /DISTRIB_ID/i; 
#		      print "scratch21: " . @scratch2[1] . "\n" ;
		      if ( @scratch2[1] ne "NONE" ) {
		          $distro = @scratch2[1] ;
			  chomp($distro) ;
		          $distro_file="" ;
		      }
                }
	}elsif(-e "/etc/debian_version"){
		$distro = 'Debian';
		$distro_file = "/etc/debian_version";
	}elsif(-e "/etc/SuSE-release"){
		$distro = 'SuSe';
		$distro_file = "/etc/SuSE-release";
	}elsif(-e "/etc/slackware-version"){
		$distro = 'Slackware';
		$distro_file = "/etc/slackware-version";
	}elsif(-e "/etc/knoppix_version"){
		$distro = 'Knoppix'; 
		$distro_file = "/etc/knoppix_version";
	}

	if(-e $distro_file){
	open DISTRO, $distro_file;
	    while(<DISTRO>){
	      chomp($OSComment=$_) ;
            }
	}

#print "OScommnet: " . $OSComment . "\n";
#print "distro is : " . $distro . "\n";

	# Memory informations
	open MEMINFO, "/proc/meminfo";
	while(<MEMINFO>){
		$PhysicalMemory=$1 if /^memtotal\s*:\s*(\S+)/i;
		$SwapFileSize=$1 if /^swaptotal\s*:\s*(\S+)/i;
	}

	# Looking for ip addresses with ifconfig, except loopback
	for(@ifconfig){
		if(/^\s*inet add?r\s*:\s*(\S+)/){
			($1=~/127.+/)?next:push @ip, $1
		};
	}
	$ip=join "/", @ip;

	# Logged on users
	for(`$who_path`){
		/^(\S+)./;
		push @users, $1 if(! &_already_in_array($1, @users));
	}
	
	$UsersLoggedOn = join "/", @users;

	# Domain
	open RESOLV, "/etc/resolv.conf";
	while(<RESOLV>){
		$domain=$2 if (/^(domain|search)\s+(.+)/);
	}

	# If no domain name, we send "WORKGROUP"
	$domain = 'WORKGROUP' unless $domain;
	if(-e "/etc/workgroup"){
		open SLWORKGROUP, "/etc/workgroup" ;
		chomp($domain = <SLWORKGROUP>);
	        }

	# Uptime
	open UPTIME, "/proc/uptime";
	$uptime = <UPTIME>;
	$uptime =~ s/^(.+)\s+.+/$1/;
	close UPTIME;

	# Uptime conversion
	($UYEAR, $UMONTH , $UDAY, $UHOUR, $UMIN, $USEC) = (gmtime ($uptime))[5,4,3,2,1,0];

	# Write in ISO format
	$uptime=sprintf "%02d-%02d-%02d %02d:%02d:%02d", ($UYEAR-70), $UMONTH, ($UDAY-1), $UHOUR, $UMIN, $USEC;

	# Hostname
	chomp(my $DeviceName=`$uname_path -n| cut -d . -f 1`);

	# CPU
	open CPUINFO, "/proc/cpuinfo";
	my($nbproc, @processors);
	while(<CPUINFO>){
		if (/^processor\s*:/){(defined($nbproc))?($nbproc++):($nbproc=0);}
		if (/^model name\s*:\s*(.+)/i){$processors{Type}=$1;}
		if (/^cpu mhz\s*:\s*(\S+)\n/i){$processors{Speed}=$1;}
	}
	
	# Writing data
	$request{'CONTENT'}{'HARDWARE'} = {
		'NAME'			=> [ $DeviceName ],
		'WORKGROUP'		=> [ $domain ],
		'OSNAME'		=> [ $OSName."($distro)" ],
		'OSVERSION'		=> [ $OSVersion ],
		'OSCOMMENTS'		=> [ $OSComment ],
		'PROCESSORT'		=> [ $processors{Type} ],
		'PROCESSORS'		=> [ $processors{Speed} ],
		'PROCESSORN'		=> [ $nbproc+1 ],
		'MEMORY'		=> [ sprintf("%i",$PhysicalMemory/UNITE) ],
		'SWAP'			=> [ sprintf("%i", $SwapFileSize/UNITE) ],
		'IPADDR'		=> [ $ip ],
		'USERID'		=> [ $UsersLoggedOn ],
		'TYPE'			=> [ '8' ],
		'DESCRIPTION'		=> [ "$DeviceType/$uptime" ],
  		#"WINCOMPANY"; Arf...
		#"WINOWNER"; Arf...
		#"WINPRODID"; Arf.
	};
	
	#Computing hardware checksum and put the whole changes flag in CHECKSUM
	&_has_changed("hardware",md5_base64($domain, $OSName, $distro, $OSVersion, $OSComment, $processors{Type}, $processors{Speed}, $nbproc,  $PhysicalMemory, $SwapFileSize)	);

}

# Account Infos
sub _accountinfo{
	for(keys(%account)){
		push @{$request{'CONTENT'}{'ACCOUNTINFO'}}, {'KEYNAME' =>  [ $_ ], 'KEYVALUE' => [ $account{$_} ] };
	}
}

# Bios infos
sub _bios{
	# Parsing dmidecode output
	# Using "type 0" section
	my(	$SystemSerial , $SystemModel, $SystemManufacturer, $BiosManufacturer,
		$BiosVersion, $BiosDate, $YEAR, $MONTH, $DAY, $HOUR, $MIN, $SEC);

	my $flag=0;
	for(@dmidecode){
		$flag=1 if /dmi type 0,/i;
		if((/dmi type (\d+),/i) && ($flag)){($1!='0')?last:1;}
		if((/^vendor\s*:\s*(.+)/i) && ($flag)) { $BiosManufacturer = $1 }
		if((/^release date\s*:\s*(.+)/i) && ($flag)) { $BiosDate = $1 }
		if((/^version\s*:\s*(.+)/i) && ($flag)) { $BiosVersion = $1 }
	}

	$flag=0;
	for(@dmidecode){
		if(/dmi type 1,/i){$flag=1;}
		if((/dmi type (\d+),/i) && ($flag)){($1!='1')?last:1;}
		if((/^serial number\s*:\s*(.+?)\s*$/i) && ($flag)) { $SystemSerial = $1 }
		if((/^product name\s*:\s*(.+?)\s*$/i) && ($flag)) { $SystemModel = $1 }
		if((/^manufacturer\s*:\s*(.+?)\s*$/i) && ($flag)) { $SystemManufacturer = $1 }
	}

	# Writing data
	$request{'CONTENT'}{'BIOS'} = {
		'SMANUFACTURER' 	=> [ $SystemManufacturer ],
		'SMODEL'		=> [ $SystemModel ],
		'SSN'			=> [ $SystemSerial ],
		'BMANUFACTURER'		=> [ $BiosManufacturer ],
		'BVERSION'		=> [ $BiosVersion ],
		'BDATE'			=> [ $BiosDate ],
	};
	
	#Checksum
	&_has_changed('bios', md5_base64($SystemManufacturer,$SystemModel,$SystemSerial,$BiosManufacturer,$BiosVersion,$BiosDate));
}


sub _accesslog{
	my ($YEAR, $MONTH , $DAY, $HOUR, $MIN, $SEC) = (localtime (time))[5,4,3,2,1,0];
	my $Date=sprintf "%02d-%02d-%02d %02d:%02d:%02d", ($YEAR+1900), ($MONTH+1), $DAY, $HOUR, $MIN, $SEC;

	$request{'CONTENT'}{'ACCESSLOG'} = {
		'USERID'		=> [ 'N/A' ],
		'LOGDATE' 		=> [ $Date ],
	};
}

sub _memories{
	# TODO: Use type 6 too
	# Using "type 17" section
	my ($n, $flag, @values);
	for(@dmidecode){
		if(/dmi type 17,/i){$flag=1; (defined($n))?($n++):($n=0);}

		if((/dmi type (\d+),/i) && ($flag)) {$flag=($1!='17'?0:1);}
		if((/^size\s*:\s*(\S+)/i) && ($flag)) {	$request{'CONTENT'}{'MEMORIES'}[$n]{'CAPACITY'}= [ $1 ]; push @values, $1}
		if((/^speed\s*:\s*(.+)/i) && ($flag)) {$request{'CONTENT'}{'MEMORIES'}[$n]{'SPEED'}	= [ $1 ]; push @values, $1}
		if((/^type\s*:\s*(.+)/i) && ($flag)) {$request{'CONTENT'}{'MEMORIES'}[$n]{'TYPE'}= [ $1 ]; push @values, $1}
		if((/^Form Factor\s*:\s*(.+)/i) && ($flag)) {$request{'CONTENT'}{'MEMORIES'}[$n]{'DESCRIPTION'}= [ $1 ]; push @values, $1}
		if((/^Locator\s*:\s*(.+)/i) && ($flag)) {$request{'CONTENT'}{'MEMORIES'}[$n]{'NUMSLOTS'} = [ $1 ]; push @values, $1}
	}
	#Checksum
	&_has_changed('memories', md5_base64(@values));
}


sub _networks{
	#Same way that dmidecode but with ifconfig
	my ($line, @network, $dhcp, $gateway, $n, $flag, $lease, @values);

	# Looking for the default gateway
	for(`$route_path`){
		$gateway=$1 if /^defau\S*\s+(\S+)/i;
	}

	# Retrieving network settings
	for $line (@ifconfig){
		if($line =~ /^([ea]th\S+)/i){
			defined($n)?($n++):($n = 0);
			$request{'CONTENT'}{'NETWORKS'}[$n]{'DESCRIPTION'} = [ $1 ];
			push @values, $1;
			$flag = 1;
			# Looking for dhcp server IP in a lease declaration (using /var/lib/dhcp/dhclient.leases)
			if(-e "/var/lib/dhcp/dhclient-" . $1 . ".leases" ){
				open DHCP, "/var/lib/dhcp/dhclient-" . $1 . ".leases";
				while(<DHCP>){
					$lease = 1 if(/lease\s*{/i);
					$lease = 0 if(/^\s*}\s*$/);
					#Interface name
					if(/interface\s+"(.+?)"\s*/ and $lease){
						($1=~ /@{$request{'CONTENT'}{'NETWORKS'}[$n]{'DESCRIPTION'}}/i)?($dhcp = 1):($dhcp = 0);
					}
					#Server IP
					if(/option\s+dhcp-server-identifier\s+(\d{1,3}(?:\.\d{1,3}){3})\s*;/ and $dhcp and $lease){
						$request{'CONTENT'}{'NETWORKS'}[$n]{'IPDHCP'} = [ $1 ];
						push @values, $1;
					}
				}
				close(DHCP);
			}
		}

		if($line =~ /^lo/){$flag = 0; next;}
		if (!$request{'CONTENT'}{'NETWORKS'}[$n]{IPGATEWAY} and $flag){ 
			$request{'CONTENT'}{'NETWORKS'}[$n]{IPGATEWAY} = [ $gateway ]; 
			push @values, $gateway;
		};
		if($line =~ /(link|lien) encap:(\S+)/i && $flag){ 
			$request{'CONTENT'}{'NETWORKS'}[$n]{'TYPE'}= [ $2 ];
			push @values, $2;
		};
  		if($line =~ /hwadd?r\s+(\S+)/i	&& $flag){ 
			$request{'CONTENT'}{'NETWORKS'}[$n]{'MACADDR'}= [ $1 ];
			push @values, $1;			
		};
		if($line =~ /inet add?r:(\S+)/i && $flag){ 
			$request{'CONTENT'}{'NETWORKS'}[$n]{'IPADDRESS'}= [ $1 ];
			push @values, $1;
		};
		if($line =~ /\S*mas(?:k|que):(\S+)/i && $flag){ 
			$request{'CONTENT'}{'NETWORKS'}[$n]{'IPMASK'}= [ $1 ];
			push @values, $1;
		};
		if($line =~ /^\s*UP/i && $flag){ 
			$request{'CONTENT'}{'NETWORKS'}[$n]{'STATUS'}= [ 'Up' ];
		}

		# Retrieving ip of the subnet for each interface
		if($request{'CONTENT'}{'NETWORKS'}[$n]{'IPMASK'}[0]
		   and $request{'CONTENT'}{'NETWORKS'}[$n]{'IPADDRESS'}[0]
		   and !$request{'CONTENT'}{'NETWORKS'}[$n]{'IPSUBNET'}[0]){
		  	# To retrieve the subnet for this iface
#CJS			my $binip = &ip_iptobin ($request{'CONTENT'}{'NETWORKS'}[$n]{'IPADDRESS'}[0] ,4);
#CJS		  	my $binmask = &ip_iptobin ($request{'CONTENT'}{'NETWORKS'}[$n]{'IPMASK'}[0] ,4);
#CJS		  	my $subnet = $binip & $binmask;
#CJS	  		$request{'CONTENT'}{'NETWORKS'}[$n]{'IPSUBNET'} = [ ip_bintoip($subnet,4) ] or warn(Error());
			push @values, $request{'CONTENT'}{'NETWORKS'}[$n]{'IPSUBNET'}[0];
		}
	}
	#Checksum
	&_has_changed('networks', md5_base64(@values));
}


sub _drives{
	my @values;
	# Looking for mount points and disk space
	for(`$df_path -TP`){
		if(/^(\S+)\s+(\S+)\s+(\S+)\s+(?:\S+)\s+(\S+)\s+(?:\S+)\s+(\S+)\n/){
			push @values, ($1,$2,$5);
			push @{$request{'CONTENT'}{'DRIVES'}}, {
				'TYPE'		=> [ $1 ],
				'FILESYSTEM'	=> [ $2 ],
				'TOTAL'		=> [ sprintf("%i",($3/UNITE)) ],
				'FREE'		=> [ sprintf("%i",($4/UNITE)) ],
				'VOLUMN'	=> [ $5 ],
			};
		}
	}
	#Checksum
	&_has_changed('drives', md5_base64(@values));
}


sub _storages{
	my(@disques, $model, $capacity, $media, $manufacturer, @rep, @scsi, @values);
	# IDE disks
	# Looking for disks name in /proc,
	# ...to access to info files of each drive
	@rep = glob "/proc/ide/hd*";

	#IDE DISKS
	for(@rep){
		if (-e "$_/capacity"){
			open CAPACITY, "$_/capacity" ;
			chomp($capacity = <CAPACITY>);
		}

		open MODEL, "$_/model";
		open MEDIA, "$_/media";

		chomp($model = <MODEL>);

		chomp($media = <MEDIA>);

		($media=~/disk/i)?($media="Hard Disk"):1;

		# We try to identify the vendor name
		if($model =~ /(maxtor|western|sony|compaq|hewlett packard|ibm|seagate|toshiba|fujitsu|lg|samsung)/i){
			$manufacturer=$1;
		}else{
			$manufacturer="??";
		}
		push @{$request{'CONTENT'}{'STORAGES'}},{
			'MANUFACTURER'	=> [ $manufacturer ],
			'MODEL'		=> [ $model ],
			'DESCRIPTION'	=> [ 'IDE' ],
			'TYPE'		=> [ $media ],
			'DISKSIZE'	=> [ $capacity?$capacity/UNITE:0 ],
		};
		push @values, ($manufacturer, $model, $media, $capacity);
	}

	#SCSI drives(/proc/scsi)
	open SCSI, "/proc/scsi/scsi";
	push @scsi, $_ while <SCSI>;

	for(@scsi){
		if(/vendor:\s*(.+)\s*model:\s*(.+)\s+rev/i){
			$manufacturer = $1;
			$model = $2;
			$_=~s/\s*$// for($manufacturer, $model);
			push @{$request{'CONTENT'}{'STORAGES'}},{
				'MANUFACTURER'	=> [  $manufacturer ],
				'MODEL'		=> [ $model ],
				'DESCRIPTION'	=> [ 'SCSI' ],
				'TYPE'		=> [ 'NA' ],
				'DISKSIZE'	=> [ 'NA' ],
			};
			push @values, ($manufacturer, $model);
		}
	}
	#Checksum
	&_has_changed('storages', md5_base64(@values));
}


sub _ports{
	# Using "type 8" section
	my ($n, $flag, @values);
	for(@dmidecode){
		if(/dmi type 8,/i){$flag=1; (defined($n))?($n++):($n=0);}
		if((/dmi type (\d+),/i) && ($flag)){($1!='8')?$flag=0:1;}
		if((/^internal reference designator\s*:\s*(.+)/i) && ($flag)) { 
			$request{'CONTENT'}{'PORTS'}[$n]{'NAME'} = [ $1 ];
			push @values, ($1);
		};
		if((/^external connector type\s*:\s*(.+)/i) && ($flag)) { 
			$request{'CONTENT'}{'PORTS'}[$n]{'CAPTION'} = [ $1 ]; 
			push @values, ($1);
		};
		if((/^internal connector type\s*:\s*(.+)/i) && ($flag)) { 
			$request{'CONTENT'}{'PORTS'}[$n]{'DESCRIPTION'} = [ $1 ]; 
			push @values, ($1);
		};
		if((/^port type\s*:\s*(.+)/i) && ($flag)) { 
			$request{'CONTENT'}{'PORTS'}[$n]{'TYPE'} = [ $1 ];
			push @values, ($1);
		};
	}
	#Checksum
	&_has_changed('ports', md5_base64(@values));
}


sub _controllers{
	my @values;
	
	for(`$lspci_path`){push @lspci, $_;}
	for(@lspci){
		/^\S+\s([^:]+):\s*(.+?)(?:\(([^()]+)\))?$/i;
		push @values, ($1,$2,$3);
		push @{$request{'CONTENT'}{'CONTROLLERS'}}, {
			'NAME'		=> [ $1 ],
			'MANUFACTURER'	=> [ $2 ],
			'TYPE'		=> [ $3 ],
		};
	}
	#Checksum
	&_has_changed('controllers', md5_base64(@values));
}


sub _slots{
	# Using "type 9" section
	my ($n, $flag, @values);
	for(@dmidecode){
		if(/dmi type 9,/i){$flag=1; (defined($n))?($n++):($n=0);}
		if((/dmi type (\d+),/i) && ($flag)){($1!='9')?$flag=0:1;}
		if((/^id\s*:\s*(.+)/i) && ($flag)){
			$request{'CONTENT'}{'SLOTS'}[$n]{'DESIGNATION'} = [ $1 ]; 
			push @values, ($1);
		};
		if((/^type\s*:\s*(.+)/i) && ($flag)){
			$request{'CONTENT'}{'SLOTS'}[$n]{'DESCRIPTION'} = [ $1 ]; 
			push @values, ($1);
		};
		if((/^designation\s*:\s*(.+)/i) && ($flag)){
			$request{'CONTENT'}{'SLOTS'}[$n]{'NAME'}= [ $1 ]; 
			push @values, ($1);
		};
		if((/^current usage\s*:\s*(.+)/i) && ($flag)){
			$request{'CONTENT'}{'SLOTS'}[$n]{'STATUS'} = [ $1 ]; 
			push @values, ($1);
		};
	}
	#Checksum
	&_has_changed('slots', md5_base64(@values));
}


sub _monitors{
	# Looking for XFConfig
	-e "/etc/X11/XF86Config" and $xfree = "/etc/X11/XF86Config";
	-e "/etc/X11/XF86Config-4" and $xfree = "/etc/X11/XF86Config-4";
	-e "/etc/XF86Config" and $xfree = "/etc/XF86Config";
	-e "/etc/Xconfig" and $xfree = "/etc/Xconfig";
	-e "/usr/X11/lib/X11/XF86Config" and $xfree = "/usr/X11/lib/X11/XF86Config";

	my ($n, $flag, @values);

	open XCONFIG, $xfree;
	@xconfig = <XCONFIG>;

	#If xfree config file found
	if($xfree){
		for(@xconfig){
			if(/section\s+("monitor")/i){
				$flag=1;(defined($n))?($n++):($n=0);
			}
			if((/endsection/i) && $flag){$flag=0;}
			if((/identifier\s+"(.+)"/i) && ($flag)) { 
				$request{'CONTENT'}{'MONITORS'}[$n]{'CAPTION'} = [ $1 ]; 
				push @values, ($1);
			};
			if((/vendorname\s+"(.+)"/i) && ($flag)) { 
				$request{'CONTENT'}{'MONITORS'}[$n]{'MANUFACTURER'}= [ $1 ]; 
				push @values, ($1);
			};
			if((/modelname\s+"(.+)"/i) && ($flag)) { 
				$request{'CONTENT'}{'MONITORS'}[$n]{'DESCRIPTION'}= [ $1 ]; 
				push @values, ($1);
			};

		}
	}
	#Checksum
	&_has_changed('monitors', md5_base64(@values));
}


sub _videos{
	my( $vendor, $name, $n, @values );
	for(@lspci){
		if(/graphics|vga|video/i){
			if(/^\S+\s([^:]+):\s*(.+?)(?:\(([^()]+)\))?$/i){
				push @values, ($1,$2);
				push @{$request{'CONTENT'}{'VIDEOS'}}, {
					'CHIPSET'	=> [ $1 ],
					'NAME'	 	=> [ $2 ]
				}
			}
		}
	}
	#Checksum
	&_has_changed('videos', md5_base64(@values));
}

sub _sounds{
	my( $vendor, $name, @values );
	for(@lspci){
		if(/audio/i){
			if(/^\S+\s([^:]+):\s*(.+?)(?:\(([^()]+)\))?$/i){
				push @values, ($1,$2,$3);
				push @{$request{'CONTENT'}{'SOUNDS'}}, {
					'MANUFACTURER'	=> [ $2 ],
					'NAME'		=> [ $1 ],
					'DESCRIPTION' 	=> [ $3 ]
				};
			}
		}
	}
	#Checksum
	&_has_changed('sounds', md5_base64(@values));
}


sub _inputs{
	my($flag, $n, @values);
	if($xfree){
		for(@xconfig){
			if(/section\s+("inputdevice")|
			section\s+("keyboard")|
			section\s+("pointer")/i){
				$flag=1;(defined($n))?($n++):($n=0);
			}
			if((/endsection/i) && $flag){$flag=0;}

			if((/identifier\s+"(.+)"/i) && ($flag)) {
				$request{'CONTENT'}{'INPUTS'}[$n]{'CAPTION'}= [ $1 ]; 
				push @values, ($1);
			};
			if((/driver\s+"(.+)"/i) && ($flag)) {
				$request{'CONTENT'}{'INPUTS'}[$n]{'TYPE'}= [ $1 ]; 
				push @values, ($1);
			};
			if((/option\s+"protocol"\s*"(.+)"/i) && ($flag)) { 
				$request{'CONTENT'}{'INPUTS'}[$n]{'INTERFACE'} = [ $1 ]; 
				push @values, ($1);
			};
		}
	}
	#Checksum
	&_has_changed('inputs', md5_base64(@values));
}


sub _modems{
	my @values;
	for(@lspci){
		if(/modem/i){
			if(/\d+\s(.+):(.+)$/){
				push @values, ($1,$2);
				push @{$request{'CONTENT'}{'MODEMS'}}, {
					'NAME'		=> [ $1 ],
					'DESCRIPTION'	=> [ $2 ],
				};
			}
		}
	}
	#Checksum
	&_has_changed('modems', md5_base64(@values));
}


sub _softwares{
	my (@liste, $dpkg, $checksum_changed, @values , $pushcount);
	my ($NAME,$VERSION,$DATEINSTALLED,$PUBLISHER,$COMMENTS) ;
	#Working with dpkg and rpm packets management
	if($distro =~/debian/i){
		my $dpkg_path = &_get_path('dpkg');
		@liste = `$dpkg_path -l`;
		$dpkg = 1;
	}elsif($distro=~/scientific|mandrake|redhat|suse/i){
		my $rpm_path = &_get_path('rpm');
		@liste = `$rpm_path -qa --queryformat "%{NAME} %{VERSION}-%{RELEASE}.%{ARCH} %{INSTALLTIME} %{BUILDHOST} %{SUMMARY}\n"`;
	}

        $pushcount = 0 ;
	if($dpkg){
		for(@liste){
			if (/^[uirph]/){
				/^(\w+)\s+(\S+)\s+(\S+)\s+(.*)/;
				push @values, ($1,$2,$3,$4);
				push @{$request{'CONTENT'}{'SOFTWARES'}}, {
					'NAME'		=> [ $2 ],
					'VERSION'	=> [ $3 ],
					'COMMENTS'	=> [ "$4($1)" ],
				};
			}else{
				next;
			}
		}
	}else{
		for(@liste){
			($NAME,$VERSION,$DATEINSTALLED,$PUBLISHER,$COMMENTS) = split(" ",$_,5);
			chomp($COMMENTS);
#			/^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s(.*)/;
#			push @values, ($1,$2,$3);
			push @values, ($NAME,$VERSION,$DATEINSTALLED,$PUBLISHER,$COMMENTS);
#PUBLISHER is BUILDHOST
			$pushcount = $pushcount + 1;
  		        push @{$request{'CONTENT'}{'SOFTWARES'}}, {
				'NAME'		=> [ $NAME ],
				'VERSION'	=> [ $VERSION ],
				'DATEINSTALLED'	=> [ $DATEINSTALLED ],
				'PUBLISHER'	=> [ $PUBLISHER ],
				'COMMENTS'	=> [ $COMMENTS ],
		        };
		}
	}
	#Checksum
	#Note that if --xml is used the first time after a change,  the
        #change will only go to xml,  we should see it again when another
        #change is made but it will not have the right delete date
        #will have to ponder this, commented out for now
	$checksum_changed = &_has_changed('softwares', md5_base64(@values)); 
	if ( $checksum_changed != 1 ) {
            #we have already added them to the xml array,  so we need to remove
            #them as they are not changed so no need to upload
#	    splice(@{$request{'CONTENT'}{'SOFTWARES'}},-$pushcount);
        }
}

sub _netstat{
	my (@values,@netstatlist, $proto,$recvq,$sendq,$localaddress,$foreignaddress,$state,$userid,$inode,$pidname,$pid,$fullcmd,$fullname,$protocol,$mytime,$psushcount);
	my ($pidname,$pid,$fullcmd,$fullname,$protocol,$mytime);

   $mytime = time();
   for $protocol ('tcp','udp','raw') {
	@netstatlist =`$netstat_path -nlpe --$protocol | tail -n +3`;
#	print @netstatlist;
	for(@netstatlist){
            	if ( $protocol eq 'udp' ) {
  			($proto,$recvq,$sendq,$localaddress,$foreignaddress,$userid,$inode,$pidname) = split(' ');
		    	$state = "-"
            	}
                else {
  			($proto,$recvq,$sendq,$localaddress,$foreignaddress,$state,$userid,$inode,$pidname) = split(' ');
            	}
  		if ($pidname ne '-') {
    			$pid = substr($pidname,0,index($pidname,"/")) ;
  			# print "\npid is " , $pid , "\n" ;
    			$fullcmd = `ps -p $pid -o cmd=`;
    			chomp($fullcmd);
  			# print " fullcmd is " , $fullcmd , "\n";
    			$fullname = `readlink /proc/$pid/exe` ;
    			chomp($fullname);
  			# print " fullname is " , $fullname , "\n" ;
  		}
		else {
  			$pid="";
  			$fullcmd="-";
  			$fullname="-";
			$fullname = "-"
                }

		push @values, ($proto, $localaddress, $foreignaddress, $userid, $fullname, $state, $fullcmd) ;
 		push @{$request{'CONTENT'}{'LISTENPORTS'}}, {
 			'PROTO'			=> [ $proto ],
 			'LOCALADDRESS'		=> [ $localaddress ],
 			'FOREIGNADDRESS'	=> [ $foreignaddress ],
 			'USERID'		=> [ $userid ],
 			'FULLNAME'		=> [ $fullname ],
 			'STATE'			=> [ $state ] ,
 	                'DATEINSTALLED'		=> [ $mytime ],
 			'FULLCMD'		=> [ $fullcmd ] 
		}  
        }
   }


   #Checksum
   &_has_changed('listenports', md5_base64(@values)); 
	   
}

sub _iptables{
   my (@iptableslist, @tableslist,@values) ;	
   my ($table,$savedtable,$chain,$chainname) ;
   my ($pkts,$bytes,$iptables,$rest,$iptablesout,$mytime) ;

	$mytime = time();
	open IPTABLEINFO, "/proc/net/ip_tables_names";
	push @tableslist, $_ while(<IPTABLEINFO>) ;
	chomp(@tableslist);

	for $table (@tableslist) 
	{
  	    @iptableslist = `$iptables_path -t $table -nvL | $grep_path -v "pkts bytes target" | $grep_path -v "ip_tables: ("`;
  	    for(@iptableslist)
  	    {
    	        if (! /^\n/)
   		{
       		    if(/^Chain/)
       		    { 
	 		if ( $chainname ) {
			        # Did not put DATEINSTALLED in here as it will be different
           	         	push @values, ($savedtable, $chainname , $iptables ) ;
 	 		        push @{$request{'CONTENT'}{'IPTABLES'}}, {
 	 		          'TABLENAME'		=> [ $savedtable ],
 	 		          'CHAINNAME'		=> [ $chainname ],
 	 		          'DATEINSTALLED'	=> [ $mytime ],
 	 		          'IPTABLESTEXT'	=> [ $iptables ] 
	 		       }  
	 		}
			$iptables = "" ;
          	        ($chain,$chainname) = split(' ');
			$savedtable = $table;
			$iptablesout = "done" ;
        	    } else {
			 ($pkts,$bytes,$rest) = split(' ',$_,3) ;
		#	 print "$pkts, $bytes, rest is =$rest \n" ;
			 $iptables = $iptables . $rest ;
			 $iptablesout = "notdone" ;
       		    }
    	        }
  	    }
#this last one handles the last one ,  since we are normally pushing on CHAIN
#lines we have to flush the final one here as there is no CHAIN line to flush 
	    if ( $iptablesout eq "notdone" ) {
		# Did not put DATEINSTALLED in here as it will be different
                push @values, ($savedtable, $chainname , $iptables ) ;
 	        push @{$request{'CONTENT'}{'IPTABLES'}}, {
 	             'TABLENAME'		=> [ $savedtable ],
 	             'CHAINNAME'		=> [ $chainname ],
 	             'DATEINSTALLED'		=> [ $mytime ],
 	             'IPTABLESTEXT'		=> [ $iptables ] 
	        }  
       	    }
       }
       #Checksum
       &_has_changed('iptables', md5_base64(@values)); 
}

sub _generate{
	my (@account, $err, $ptmontage, $values, $i, $content);

	# If $local is set , we know that the inventory is generated on the local machine
	if($local or $xml){
		$err=1;
		while($err){
		        if ($local and $XmlLocalDir) {
			        $ptmontage=$XmlLocalDir ;
                        } else {
				print "\n\n\tChoose your target directory ? :  ";

				chomp($ptmontage=<STDIN>);
                        }

			# Checking existence and permissions of the destination directory
			if(!(-e $ptmontage)){
				print "The directory do not exist .\n";
				$err++;
			}elsif(!(-w $ptmontage)){
				print "The mount point is not writeable.\n";
				$err++;
			# Generate...
			}else{
				$err = 0;
				open XML, ">$ptmontage/$DeviceID.ocs" or die localtime()." => Cannot create file : $!\n";

				if($xml){
					print XML $inventory;
				}else{
				 	&_debug($inventory, 'SENDING') if $debug and $debug>1;
					$inventory = Compress::Zlib::compress( $inventory ) or die localtime()." => Compression error\n";
					binmode XML;
					print XML $inventory
				}
				close XML;
			}

			die("Abort. Local xml filename bad , $ptmontage \n") if $err>3;
		}
		print localtime()." => Inventory generated...\n";
	}else{
		# Sending inventory to web server

		# Request construction
		$req = HTTP::Request->new(POST => $URI);

		$req->header('Pragma' => 'no-cache', 'content-type' => 'application/x-compress', 'Connection' => 'keep-alive');

		&_debug($inventory, 'SENDING') if $debug and $debug>1;

		$inventory=Compress::Zlib::compress( $inventory ) or die localtime()." => Compression error\n";

		$req->content($inventory);

		# Sending
		my $res = $ua->request($req);

		# Checking response
		if($res->is_success){
			print localtime()." => Transmission...done.\n";
		}else{
			print localtime()." => Cannot transmit inventory ->".$res->status_line, "\n";
			exit(1);
		}

		# If we receive account informations, we write it to the admin file
		$content = _uncompress($res->content)  or die localtime()." => Cannot read the server message (code $content)\n";

		&_debug($content, 'RECEIVING') if $debug and $debug>1;

		$xml=XML::Simple::XMLin( $content, ForceArray => ['ACCOUNTINFO', 'KEYNAME', 'KEYVALUE'], SuppressEmpty => undef);

		if($xml->{RESPONSE}=~/^no_account_update/i){
			print localtime()." => Account infos up to date\n";
		}elsif($xml->{RESPONSE}=~/^account_update/i){
			delete $xml->{RESPONSE};

			$xml=XML::Simple::XMLout( $xml, RootName => 'ADM', NoSort => 1 );

			print localtime()." => Updating Account infos\n";

			open ADM, ">".$install_path."/ocsinv.adm";
			print ADM $xml;
			close ADM;
		}else{
			print localtime()." => Problem with account infos : $content\n";
		}
	}
}

sub _inventory{
	# Query type is INVENTORY
	$request{'QUERY'} = ['INVENTORY'];

	# Writing DeviceID
	$request{'CONTENT'}{'DEVICEID'} = [ $DeviceID ];

	# Writing old deviceid if needed
	$request{'CONTENT'}{'OLD_DEVICEID'} = [ $old_deviceid ] if $old_deviceid;

	# Launching subroutines
	&_hardware;
	&_accountinfo;
	&_bios;
	&_accesslog;
	&_memories;
	&_networks;
	&_drives;
	&_storages;
	&_ports;
	&_controllers;
	&_slots;
	&_monitors;
	&_videos;
	&_sounds;
	&_inputs;
	&_modems;
	&_softwares;
	&_netstat;
	&_iptables;
	&_save_checksums;
	&_options;
	#
	$end = time();

	$request{'CONTENT'}{'HARDWARE'}{'ETIME'} = [ $end - $start ];
	# Convert perl data structure into xml string
	$inventory = XMLout( \%request, RootName => 'REQUEST', XMLDecl => '<?xml version="1.0" encoding="ISO-8859-1"?>', NoSort => 1, SuppressEmpty => undef );

	# Create/send inventory
	&_generate;
}

# We ask to server if we have to send an inventory
sub _prolog{
	my ($message, $xml, $resp, $content);

	%request = ();

	# Generation of xml message
	$request{'QUERY'} = ['PROLOG'];
	$request{'DEVICEID'} = [$DeviceID];

	$message=XMLout( \%request, RootName => 'REQUEST', XMLDecl => '<?xml version="1.0" encoding="ISO-8859-1"?>',
	                 NoSort => 1, SuppressEmpty => undef );

	#####
	#HTTP
	#####
	$req = HTTP::Request->new(POST => $URI);

	$req->header('Pragma' => 'no-cache', 'Content-type', 'application/x-compress');

	&_debug($message, 'SENDING') if $debug and $debug>1;

	$message = Compress::Zlib::compress( $message )  or die localtime()." => Probleme de compression(prolog)\n";

	$req->content($message);

	$res = $ua->request($req);

	# Checking if connected
	unless($res->is_success) {
		die localtime()." => Cannot establish communication : ".$res->status_line, "\n";
	}

	# stop or send in the http's body
	$content = _uncompress($res->content)  or die localtime()." => Deflating problem (prolog, code= $content )\n";

	&_debug($content, 'RECEIVING') if $debug and $debug>1;

	$xml = XML::Simple::XMLin( $content, ForceArray => ['OPTION'] );

	# Options management (ipdiscover only is implemented at this time)
	for(@{$xml->{OPTION}}){
	  if( $_->{NAME} =~/ipdiscover/i){
	    $options{'ipdiscover'} = $_->{PARAM};
	  }
	}

	if($xml->{RESPONSE} eq 'STOP'){
		print localtime()." => Inventory not generated, command by server...\n";
		return(0);
	}elsif($xml->{RESPONSE} eq 'SEND'){
		return(1);
	}else{
		die localtime()." => Server response unreadable : ".$content."\n";
	}
}

sub _uncompress{
	my($status, $data, $d);

	# Uncompress request
	($d, $status) = Compress::Zlib::inflateInit();
	($data, $status) = $d->inflate($_[0]);

	return ($data);
}

# Update or not
sub _update{

	my (@resp, $ASversion, $ISversion, $DSversion, @conf, $res, $old, $message, $xml, $content, $ipflag, $dmiflag, $update);

	# Sending our current version
	# Generation of xml message
	$request{'QUERY'}      = [ 'UPDATE' ];
	$request{'PLATFORM'}   = [ 'LINUX' ];
	$request{'AGENT'}      = [ VERSION ];
	unless($_[0] eq 'test'){
	  $request{'DMI'}        = [ $Dversion ];
	  $request{'IPDISCOVER'} = [ $Iversion ];
	}

	$message = XMLout( \%request, RootName => 'REQUEST', XMLDecl => '<?xml version="1.0" encoding="ISO-8859-1"?>',
	                  NoSort => 1, SuppressEmpty => undef );
	&_debug($message, 'SENDING') if $debug and $debug>1;

	# sending
	if($_[0] eq 'test'){

		$URI = "http://".$ServerName."/ocsinventory";
		$ua  = LWP::UserAgent->new();
		$req = HTTP::Request->new(POST => $URI);

		$req->header('Pragma' => 'no-cache', 'Content-type' => 'application/x-compress');
		$message=Compress::Zlib::compress( $message )  or die localtime()." => Deflation problem (update)\n";
		$req->content($message);
		$res = $ua->request($req);
	}else{
		$req = HTTP::Request->new(POST => $URI);
		$req->header('Pragma' => 'no-cache', 'Content-type' => 'application/x-compress', 'Connection' => 'Keep-alive');
		$message = Compress::Zlib::compress( $message )  or die localtime()." => Inflating problem (update)\n";
		$req->content($message);
		$res = $ua->request($req);
	}

	unless($res->is_success) {
		die localtime()." => Update failed : ".$res->status_line, "\n";
	}
	
	$content = _uncompress($res->content)  or die localtime()." => Inflating problem (update)\n";
	&_debug($content, 'RECEIVING') if $debug and $debug>1;
	$xml=XML::Simple::XMLin( $content , SuppressEmpty => undef);

	# If we are currently testing an update, the server MUST answer update=0
	if($_[0] eq 'test'){
		if($xml->{RESPONSE} eq 'UPDATE'){
			print "Le test d'update a �chou�\n" if $debug;
			exit(1);
		}elsif($xml->{RESPONSE} eq 'NO_UPDATE'){
			#If the script is running with the -update parameter, we send 'ok'
			print 'ok';
			return;
		}
	}

	# The server tell us what files to ask
	if($xml->{RESPONSE} eq 'UPDATE'){
		$update=1;
	}elsif($xml->{RESPONSE} eq 'NO_UPDATE'){
		$update=0;
	}else{
		print localtime()." => Update response not readable : ".$content."\n";
		return;
	}
	# Update or not
	if($update){
		# Wich versions ?
		if(($xml->{AGENT})){$ASversion=$xml->{AGENT}}
		if(($xml->{DMI})){$DSversion=$xml->{DMI}}
		if(($xml->{IPDISCOVER})){$ISversion=$xml->{IPDISCOVER}}

		# OCS AGENT
		if(($ASversion)){
			die("Relaunch ocs agent. Quitting.\n\n") unless &_update_file($exe_path."/ocsinventory-client.pl", $ASversion);
		}

		# DMI AGENT
		if(($DSversion)){
			if($dmidecode_path){
				$dmiflag = 1 unless &_update_file($dmidecode_path, $DSversion);
			}
		}
			
		# IPDISCOVER AGENT
		if($ISversion){
			if($ipdiscover_path){
				$ipflag = 1 unless &_update_file($ipdiscover_path, $ISversion);
			}
		}
		
		# Writing new versions to .conf
		if($ipflag or $dmiflag){
		  #writing ocsinv.conf
		  my %xmlconf;
		  #
		  $xmlconf{'DEVICEID'}   = [ $DeviceID ];
		  $xmlconf{'OCSFSERVER'} = [ $ServerName ];
		  $xmlconf{'DMIVERSION'} = $dmiflag?[ $DSversion ]:[ $Dversion ];
		  $xmlconf{'IPDISCOVER_VERSION'} = $ipflag?[ $ISversion ]:[ $Iversion ];
		  $xmlconf{'UPDATE'}     = [ "1" ] if $AuthUpdate;
		  #
		  my $xml = XML::Simple::XMLout( \%xmlconf, RootName => 'CONF' );
		  #
		  open CONF, ">$install_path/ocsinv.conf";
		  print CONF $xml;
		  close CONF;
		}
	}else{
		print localtime()." => No update\n";
	}
	0;
}

sub _options{
	if($options{'ipdiscover'}){
		my ($iface,$ipdiscover);

		#We get the iface name for the related subnet
		for(@{$request{'CONTENT'}{'NETWORKS'}}){
			if($_->{'IPSUBNET'}[0] eq $options{'ipdiscover'}){
				$iface = $_->{'DESCRIPTION'}[0];
				last;
			}
		}

		return if(!$iface or !$ipdiscover_path);
		#and we launch the ipdiscover
		$ipdiscover = `$ipdiscover_path $iface`;

		if($ipdiscover){
			$request{'CONTENT'}{'IPDISCOVER'} = XML::Simple::XMLin( $ipdiscover, ForceArray => 'H');
		}

	}
}

sub _update_file{
	my $path = shift;
	my $name; 
	my $version = shift;
	my $content;
	my $fail;
	my $agent;
	
	#If it's a binary, we retrieve the filename
	if($path=~/ocsinventory-client.pl$/){
		$agent = 1;
		$name = 'agent';
	}else{
		($name) = $path=~/\/([^\/]+)$/;
	}
	
		
	print localtime()." => updating $name... to the version $version\n";
	
	# We ask file to server
	# We construct url on the fly to take some benefits about proxies
	
	&_debug("Asking for an updated file\nGET $URI/update/linux/$name/$version/", "SENDING") if $debug>1;
	
	$req = HTTP::Request->new(GET => "$URI/update/linux/$name/$version/");
	unless($res = $ua->request($req)){
		warn localtime()." => Cannot get $name\n = $!";
		return(1);
	}
	
	unless($res->is_success){
		warn localtime()." => Update problem with $name\n";
		return(1);
	}else{
		unless($content = _uncompress($res->content)){
			warn localtime()." => Inflating problem (update)\n";
			return(1);
		}
		########
		#UPDATE#
		#############################
		# Put the binary content in memory
		unless(open FILE, $path){
			warn "Cannot update $name : $!\n";
			return(1);
		}
		
		local $/;
		my $old = <FILE>;
		
		open FILE, ">".$path;
		# Writing the new data
		print FILE $content;
		close FILE;
		# We run the script with -update parameter, in order to test update system
		# The script must send 'ok'
		if($agent){
			$fail = 1 unless `$0 -update` eq 'ok';
		}else{
			$fail = 1 if system("$path > /dev/null");
		}
		# Testing the return value of the binary
		if($fail){
			open FILE, ">".$path or die "Cannot go back to the previous version : $!\n";
			print FILE $old;
			close FILE;
			print localtime()." => Problem with $name update. Go back to the previous version\n";
			return(1);
		}else{
			print localtime()." => $name updated\n";
			return(0);
		}
	}
}

#For debugging purposes
sub _debug{
	my $message = shift;
	my $context = shift;
	$message =~ s/^([^#].*)/#  $1/gm;
	my $debug = <<EOT;


[ $context ]####################################
$message
################################################





EOT



print $debug;
}

sub _get_path{
	my $binary = shift;
	my $path;
	
	print "\n=> retrieving $binary...\n" if $debug;
	for($exe_path,@bin_directories){
		$path = $_.$binary,last if -x $_.$binary;
	}
	
	#For debbuging purposes
	if($path){
		print "=> $binary is at $path\n\n" if $debug;
	}else{
		print "$binary not found (Maybe it is not installed ?) - Some functionnalities may lack !!\n\n" ;
	}
	
	return $path;
}

# A little contribution
sub _already_in_array {
	my $lookfor = shift;
	my @array   = @_;
	foreach (@array){
	return 1 if($lookfor eq $_);
	}
	return 0;	 
}

sub _has_changed{
	my $section 	= shift;
	my $hash	= shift;
	if($last_state){
		#If the checksum has changed...
		if($last_state->{$section}[0] ne $hash){
			print "Section $section has changed since last inventory( ".$last_state->{$section}[0]." --> ".$hash.")\n" if $debug;
			#We made OR on $checksum with the mask of the current section
			$checksum |= $mask{$section};
			print "checksum is : " . $checksum . "\n" if $debug;
			#And we replace the hash with the new value
			$last_state->{$section} = [ $hash ];
			return 1;
		}
	}else{
		$checksum |= $mask{$section};
			print "checksum is : " . $checksum . "\n" if $debug;
		$last_state{$section} = [ $hash ];
		return 1;
	}
}

sub _save_checksums{
	$last_state = \%last_state unless $last_state;
	my $string = XML::Simple::XMLout( $last_state, RootName => 'LAST_STATE' );
	open LAST_STATE, ">$install_path/last_state" or warn "Cannot save the checksum values (will be synchronized by GLPI!!): $!\n";
	print LAST_STATE $string;
	close LAST_STATE;
	my $base = $request{'CONTENT'}{'HARDWARE'};
	$base->{'CHECKSUM'} = [ $checksum ];
}
